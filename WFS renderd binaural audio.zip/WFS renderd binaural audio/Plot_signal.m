% date: 01 May 2025
% Description:
% Load the audio files and plot the time history.

clc
clear
close all

[Audio1 Fs1] =audioread("Audio_WFS_DL=0.10cm_Rs=3.00m.wav");

[Audio2 Fs2] =audioread("Audio_WFS_DL=0.10cm_Rs=6.50m.wav");

%%
figure (1)
plot(Audio1(:,1),'.-r');
hold on
plot(Audio1(:,2),'--b');
legend('Ear1 signal','Ear2 signal')
grid on
title('Comparing the Left and right audio channel rendered by a virtual moving source')
figure (2)
plot(Audio1(:,1),'--m');
hold on
plot(Audio2(:,1),'--k');
legend('Ear1 signal: Rs=3 meter','Ear1 signal: Rs=6.5 meter')
grid on
title('Comparing the Audio signals rendered at a point for two different virtual source path')